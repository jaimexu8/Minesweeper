The game is played by left-clicking to clear tiles and right-clicking to flag tiles as mines
The numbers displayed on the tiles indicate the number of adjacent and diagonally-neighboring mines
There is a drop-down box for themes and a drop-down box for game difficulty
To restart the field, you can select the difficulty drop-down box and choose a difficulty again

Bugs
The game will occasionally display the wrong number on a tile, resulting in an unfair loss